#ifndef BOURSE_H_INCLUDED
#define BOURSE_H_INCLUDED
#include "PrixJournalier.h"
#include<vector>
#include"Date.h"
#include<set>
class Bourse
{
    protected:
        Date Date_Ajourdhui;
        vector<PrixJournalier> historique;
    public:
        Bourse(Date DateAjourdhui,vector<PrixJournalier>historique);
        ~Bourse();
        Date getDateAujourdhui();
        virtual set<string> getActionsDisponiblesParDate(Date &d);
        virtual vector<PrixJournalier> getPrixJournaliersParDate(Date &d);
};
#endif // BOURSE_H_INCLUDED
