#ifndef BOURSEVECTOR_H_INCLUDED
#define BOURSEVECTOR_H_INCLUDED
#include"Bourse.h"
#include<iostream>
using namespace std;
class BourseVector: public Bourse
{
    public:
        set<string> getActionsDisponiblesParDate(Date d);
        vector<PrixJournalier> getPrixJournaliersParDate(Date d);
};



#endif // BOURSEVECTOR_H_INCLUDED
