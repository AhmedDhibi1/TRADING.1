#include "Date.h"
#include"PrixJournalier.h"
#include"PersistancePrixJournalier.h"
#include "Bourse.h"
#include<set>
#include<iostream>
#include<string>
#include<stdlib.h>
#include<vector>
Bourse::Bourse(Date DateAjourdhui,vector<PrixJournalier> history)
{
    Date_Ajourdhui=DateAjourdhui;
    historique=history;

}
Bourse::~Bourse()
{

}
Date Bourse::getDateAujourdhui()
{
    return Date_Ajourdhui;
}

set<string> Bourse::getActionsDisponiblesParDate(Date &d)
{

    set<string> ads;
    if((d<Date_Ajourdhui)&&(d<historique[historique.size()].GetDate())&&(historique[0].GetDate()<d))
    {
        int i=0;
        while(i<static_cast<int>(historique.size()))
        {
            if(historique[i].GetDate()==d)
            {
                ads.insert(historique[i].GetNomAction());
            }
            i++;
        }
    }
    return ads;

}
vector<PrixJournalier> Bourse::getPrixJournaliersParDate(Date &d)
{
    vector<PrixJournalier> pjs;
    if(d<Date_Ajourdhui)
    {
        int i=0;
        while(i<static_cast<int>(historique.size()))
        {
            if(historique[i].GetDate()==d)
            {
                pjs.push_back(historique[i]);
            }
        }
    }
    return pjs;
}


