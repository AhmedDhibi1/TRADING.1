#include <iostream>
#include <vector>
#include "Date.h"
#include "PrixJournalier.h"
#include "PersistancePrixJournalier.h"
#include "Bourse.h"
#include "BourseVector.h"
using namespace std;

int main()
{
    Date date(01,02,2012);
    PrixJournalier pj;
    PersistancePrixJournaliers ppj;
    vector<PrixJournalier> vpj;
    Bourse b(date,vpj);
    vpj=ppj.lirePrixJournaliersDUnFichier("C:\\Users\\USER\\Desktop\\MonProjet\\prices_simple.csv");
    /*
    for(int i=0;i<static_cast<int>(vpj.size());i++)
    {
        cout<<vpj[i];
    }
    */
    b.getActionsDisponiblesParDate(date);
    b.getPrixJournaliersParDate(date);
    return 0;
}
