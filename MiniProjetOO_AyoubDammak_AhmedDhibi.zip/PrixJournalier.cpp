#include "PrixJournalier.h"
#include "Date.h"
#include<cstring>
#include<iostream>
#include<cstdlib>
#include<sstream>
#include<cstdlib>
#include<string>
PrixJournalier::PrixJournalier(string s,double p,Date da)
{
    nomAction=s;
    prix=p;
    d=da;
}
PrixJournalier::PrixJournalier()
{

}
PrixJournalier::~PrixJournalier()
{

}
string PrixJournalier::GetNomAction()const
{
    return (this->nomAction);
}
double PrixJournalier::GetPrix()const
{
    return (this->prix);
}
Date PrixJournalier::GetDate()const
{
    return (this->d);
}

ostream& operator<<(ostream& flux,  PrixJournalier &Pj)
{
    flux<<Pj.d<<":"<<Pj.nomAction<<":"<<Pj.prix;
    return flux;
}

istream& operator>>(istream& flux, PrixJournalier& pj)
{
    /*
    string ligne;
    int pos=0;
    getline(flux,ligne,'\n');
    pos=ligne.find(";");
    string date=ligne.substr(0, pos);
    ligne.erase(0, pos +1);
    pos=ligne.find(";");
    string symbol=ligne.substr(0, pos);
    ligne.erase(0, pos +1);
    stringstream ss(date);
    ss>>pj.d;
    pj.nomAction = symbol;
    pj.prix =stod(ligne);
    return flux;
    */
    char tab[100];
    flux>>pj.d;
    flux.getline(tab,100,';');
    pj.nomAction=tab;
    flux.getline(tab,100);
    pj.prix=atof(tab);
    return flux;
}


