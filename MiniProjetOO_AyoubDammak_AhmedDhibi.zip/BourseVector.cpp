#include "PrixJournalier.h"
#include<vector>
#include"Date.h"
#include"PersistancePrixJournalier.h"
#include<set>
#include<iostream>
#include<stdlib.h>
#include<cstring>
#include"BourseVector.h"
vector<PrixJournalier> BourseVector::getPrixJournaliersParDate(Date d)
{
    vector<PrixJournalier> tab;
    vector<PrixJournalier>  historiques;
    Date i,f;
    i=historiques[0].GetDate();
    f=historiques[historiques.size()].GetDate();
    if((d<i)||(f<d))
    {
        cerr<<"date introuvable"<<endl;
    }
    else{
        for(int j=0;j<static_cast<int>(historiques.size());j++){
             Date t;
             t=historiques[j].GetDate();
             if((d==t)==true)
             {
                tab.push_back(historiques[j]);
             }
        }
    }
    return tab;
}
set<string> BourseVector:: getActionsDisponiblesParDate(Date d)
{
    vector<PrixJournalier> historiques;
    set<string> tab;
    Date it,f;
    it=historiques[0].GetDate();
    f=historiques[historiques.size()-1].GetDate();


    if((d<it)||(f<d)){
        cerr<<"date introuvable"<<endl;
        exit(0);
    }
    else
        {
        for(int j=0;j<static_cast<int>(historiques.size());j++){

             Date t;
             t=historiques[j].GetDate();

             if((d==t)==true)
             {
                tab.insert(historiques[j].GetNomAction());
             }

            else
                break;




                }

             }

     return tab;



}
